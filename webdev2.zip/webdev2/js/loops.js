let studentList=["sandesh", "sanjeet", "sandeep", "sanjay", "ratan", 20 , 20, 20, 20, 20];
for(let i = 0; i <= studentList.length; i++){
   console.log(studentList[[i],[i]]);
   // console.log(studentList[3]);
}